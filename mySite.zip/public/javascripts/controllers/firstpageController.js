app.controller('firstpageController', ['$scope','$window', function($scope,$window) {

  $scope.qq="pop";
   

     
}]);